
data_output = "output.sh"
data_input = open("input.txt", "r")




server = "scp oper@edge1.ringlabskiev.com://mnt/markup-dumps/dumps/"
create_folder = "mkdir ~/Data/india_team/"
save_to = " ~/Data/india_team/"
back_slash = "/"
json = ".json"
enter = "\n"
mp4 = ".mp4"
dot = "."
write = "w"
string = ""

file = open(data_output, write)
file.write(create_folder + enter)
all_items = string
for line in data_input:
        line_array = line.split(dot)
        item = (
                create_folder + line_array[0] + enter +
                create_folder + line_array[0] + back_slash + line_array[1] + enter +
                server + line_array[0] + back_slash + line_array[1] + back_slash + line_array[0] + dot + line_array[1] + mp4 + save_to + line_array[0] + back_slash + line_array[1] + enter +
                server + line_array[0] + back_slash + line_array[0]+ json + save_to + line_array[0]+ enter
        	)
                        
        all_items += item
file.write(all_items)
file.close()
                 
data_input.close() 
